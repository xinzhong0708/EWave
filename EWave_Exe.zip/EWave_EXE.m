%==========================================================================
% This is the separate code for Zhong, X., Frehner, M. CAGEO, 2018.       %
% This code is complementary to the GUI and can be executed separately    %
% using the variables defined by user in the script.                      %
% In case one wants to use multi-thread clusters to compute Vp as a       %
% function of rotation angle, the parameters can be changed here.         %
%                                                                         %
% Xin Zhong, Feb-2018, Oslo.                                              %
% Email: xinzhong0708@gmail.com                                           %
%==========================================================================
%Prepare
clear;clf;addpath([pwd,'\bin']);load wave;colormap(cmap)
%==========================================================================
% USER INPUT HERE
EXCEL_NAME              =  'data.xlsx';  % excel file name (in current directory)
par.x_center            =   5000;        % model center in micro m
par.y_center            =   5000;        % model center in micro m
par.x_length            =   2500;        % model length in micro m
par.y_length            =   2500;        % model length in micro m
par.rotation_angle      =   5/180*pi;    % rotation angle in radian
par.rotate_cpo          =   1;           % 1-rotate CPO; 0-NOT rotate
par.wavelength          =   200;         % wavelength in micro m
par.transducer          =   800;         % buffer length in micro m
par.wave_mode           =   1;           % 1-vp; 2-vs1; 3-vs2
par.run_time            =   0.5;         % run time in micro s
par.snapshot            =   0.01;        % plot interval in micro second

%==========================================================================
%Load data
disp('Loading data')
data                    =   Load_Data(EXCEL_NAME);
S_tensor                =   Load_Tensor(EXCEL_NAME,data);
%Clip the modelling window
data                    =   Rotate_Window(data,par);
%Numerical setup
dx                      =   data.x2(2,2)-data.x2(1,1);
dy                      =   data.y2(2,2)-data.y2(1,1);
Lx                      =   max(data.x2(:))-min(data.x2(:));
Ly                      =   max(data.y2(:))-min(data.y2(:));
nx                      =   size(data.x2,2);
ny                      =   size(data.x2,1);
%==========================================================================
%Rotate CPO
if par.rotate_cpo  ==   1
    R_SPO               =   par.rotation_angle;
end
if par.rotate_cpo  ==   0
    R_SPO               =   0;
end
phase_num               =   unique(data.phase);
%Rotate M matrix
for i = 1:size(data.x2,1)
    for j = 1:size(data.x2,2)
        %Rotation of CPO
        M               =   1e9*S_tensor.M{phase_num==data.phase(i,j)};
        %Rotate CPO
        C               =   Rotation_4nd(M,data.phi1(i,j),data.psi(i,j),data.phi2(i,j));
        %Rotate SPO
        C               =   Rotation_4nd(C,         R_SPO,0            ,0             );
        for k = 1:size(C,1)
            for l = 1:size(C,2)
                C_All{k,l}(i,j)        =   C(k,l);
            end
        end
        %Density
        rho(i,j)        =   S_tensor.rho(phase_num==data.phase(i,j));
    end
end
%==========================================================================
%Add Al transducer
rho1                    =   2710;
lb                      =   63e9;
G                       =   23e9;
C11                     =   lb + 2*G;
C12                     =   lb;
C44                     =   G;
M_alm                   =  [C11 C12 C12 0   0   0
                            C12 C11 C12 0   0   0 
                            C12 C12 C11 0   0   0
                            0   0   0   C44 0   0 
                            0   0   0   0   C44 0
                            0   0   0   0   0   C44];

%Put transducer
n_al                    =   floor(par.transducer/dx);
x                       =   linspace(0,Lx+par.transducer*2,nx+n_al*2+1);
y                       =   linspace(0,Ly                 ,ny       +1);
[x2,~]                  =   meshgrid(x,y);
rho                     =  [rho1*ones(ny,n_al),rho       ,rho1*ones(ny,n_al)]; rho=avv2(rho);
for k = 1:size(C,1)
    for l = 1:size(C,2)
        C_All{k,l}      =  [M_alm(k,l)*ones(ny,n_al),C_All{k,l},M_alm(k,l)*ones(ny,n_al)];
    end
end
%==========================================================================
%Initial Wave
mag                  =   2;
sigma                =   par.wavelength;
if par.wave_mode==1
    ux               =   mag*(1-x2.^2/sigma^2).*exp(-x2.^2/2/sigma^2);
    uy               =     0*(1-x2.^2/sigma^2).*exp(-x2.^2/2/sigma^2);
    uz               =     0*(1-x2.^2/sigma^2).*exp(-x2.^2/2/sigma^2);
end
if par.wave_mode==2
    ux               =     0*(1-x2.^2/sigma^2).*exp(-x2.^2/2/sigma^2);
    uy               =   mag*(1-x2.^2/sigma^2).*exp(-x2.^2/2/sigma^2);
    uz               =     0*(1-x2.^2/sigma^2).*exp(-x2.^2/2/sigma^2);
end
if par.wave_mode==3
    ux               =     0*(1-x2.^2/sigma^2).*exp(-x2.^2/2/sigma^2);
    uy               =     0*(1-x2.^2/sigma^2).*exp(-x2.^2/2/sigma^2);
    uz               =   mag*(1-x2.^2/sigma^2).*exp(-x2.^2/2/sigma^2);
end
vx                   =   zeros(size(ux));
vy                   =   zeros(size(uy));
vz                   =   zeros(size(uz));
%Time increment
for im = 1:length(S_tensor.M)
    C_max(im)        =   1e9*max(max(S_tensor.M{im}));
end
dt                   =   min([dx,dy])*sqrt(min(S_tensor.rho)/max(C_max))/4;
par.snapshot         =   round(par.snapshot/dt);
%Time loop
disp('Start simulation')
for it = 1:par.run_time/dt
    %calculate strain
    epsilonxx            =   ava2(diffa2(ux,2)/dx,1);
    epsilonyy            =   ava2(diffa2(uy,1)/dy,2);
    epsilonyz            =   ava2(diffa2(uz,1)/dy,2);
    epsilonxz            =   ava2(diffa2(uz,2)/dx,1);
    epsilonxy            =   ava2(diffa2(ux,1)/dy,2) + ...
                             ava2(diffa2(uy,2)/dx,1);
    %elastic rheology
    sigmaxx              =   C_All{1,1}.*epsilonxx + C_All{1,2}.*epsilonyy + C_All{1,4}.*epsilonyz + C_All{1,5}.*epsilonxz + C_All{1,6}.*epsilonxy;
    sigmayy              =   C_All{2,1}.*epsilonxx + C_All{2,2}.*epsilonyy + C_All{2,4}.*epsilonyz + C_All{2,5}.*epsilonxz + C_All{2,6}.*epsilonxy;
    sigmayz              =   C_All{4,1}.*epsilonxx + C_All{4,2}.*epsilonyy + C_All{4,4}.*epsilonyz + C_All{4,5}.*epsilonxz + C_All{4,6}.*epsilonxy;
    sigmaxz              =   C_All{5,1}.*epsilonxx + C_All{5,2}.*epsilonyy + C_All{5,4}.*epsilonyz + C_All{5,5}.*epsilonxz + C_All{5,6}.*epsilonxy;
    sigmaxy              =   C_All{6,1}.*epsilonxx + C_All{6,2}.*epsilonyy + C_All{6,4}.*epsilonyz + C_All{6,5}.*epsilonxz + C_All{6,6}.*epsilonxy;
    %solve momentum balance 
    ax                   =   diffa2(ava2(sigmaxx,1),2)/dx./rho + diffa2(ava2(sigmaxy,2),1)/dy./rho;
    ay                   =   diffa2(ava2(sigmaxy,1),2)/dx./rho + diffa2(ava2(sigmayy,2),1)/dy./rho;
    az                   =   diffa2(ava2(sigmaxz,1),2)/dx./rho + diffa2(ava2(sigmayz,2),1)/dy./rho;
    %update velocity using momentum
    vx                   =   updatei2(vx,ax*dt);
    vy                   =   updatei2(vy,ay*dt);
    vz                   =   updatei2(vz,az*dt);
    %update displacement using velocity         
    ux                   =   updatea2(ux,vx*dt);
    uy                   =   updatea2(uy,vy*dt);
    uz                   =   updatea2(uz,vz*dt);
    %Neumann boundary left
    ux(:,1)              =   ux(:,2);
    uy(:,1)              =   uy(:,2);
    uz(:,1)              =   uz(:,2);
    %Neumann boundary right
    ux(:,end)            =   ux(:,end-1);
    uy(:,end)            =   uy(:,end-1);
    uz(:,end)            =   uz(:,end-1);
    %Neumann boundary top
    ux(1,:)              =   ux(2,:);
    uy(1,:)              =   uy(2,:);
    uz(1,:)              =   uz(2,:);
    %Neumann boundary bottom
    ux(end,:)            =   ux(end-1,:);
    uy(end,:)            =   uy(end-1,:);
    uz(end,:)            =   uz(end-1,:);
    %receivers
    rec_l_x(it)          =  (mean(ux(:,n_al   )));
    rec_r_x(it)          =  (mean(ux(:,n_al+nx)));
    rec_l_y(it)          =  (mean(uy(:,n_al   )));
    rec_r_y(it)          =  (mean(uy(:,n_al+nx)));
    rec_l_z(it)          =  (mean(uz(:,n_al   )));
    rec_r_z(it)          =  (mean(uz(:,n_al+nx)));
    time( it)            =   it*dt;
    %plotting
    if mod(it,par.snapshot)==0 || it == 1
        if par.wave_mode==1
            subplot(211);cla;pcolor(x,y,ux),caxis([-mag,mag]/2);axis equal;colorbar;axis on;shading interp;hold on;plot([par.transducer,par.transducer],[0,Ly],'k',[par.transducer+Lx,par.transducer+Lx],[0,Ly],'r','LineWidth',1.5);plot([0,0],[0,Ly],'k--',[0,Lx+2*par.transducer],[Ly,Ly],'k--',[0,Lx+2*par.transducer],[0,0],'k--',[Lx,Lx]+2*par.transducer,[0,Ly],'k--','LineWidth',1.5);hold off;title('x displacement \mum');
            subplot(212);cla;plot(dt*[1:length(rec_l_x)],(rec_l_x),'k',dt*[1:length(rec_l_x)],(rec_r_x),'r','LineWidth',1.5);axis on,box on;ylim([-mag/2,mag/2]*1.05);set(gca,'ytick',[]);xlabel('receiver signal (\mus)')
        end
        if par.wave_mode==2
            subplot(211);cla;pcolor(x,y,uy),caxis([-mag,mag]/2);axis equal;colorbar;axis on;shading interp;hold on;plot([par.transducer,par.transducer],[0,Ly],'k',[par.transducer+Lx,par.transducer+Lx],[0,Ly],'r','LineWidth',1.5);plot([0,0],[0,Ly],'k--',[0,Lx+2*par.transducer],[Ly,Ly],'k--',[0,Lx+2*par.transducer],[0,0],'k--',[Lx,Lx]+2*par.transducer,[0,Ly],'k--','LineWidth',1.5);hold off;title('y displacement \mum');
            subplot(212);cla;plot(dt*[1:length(rec_l_y)],(rec_l_y),'k',dt*[1:length(rec_l_y)],(rec_r_y),'r','LineWidth',1.5);axis on,box on;ylim([-mag/2,mag/2]*1.05);set(gca,'ytick',[]);xlabel('receiver signal (\mus)')
        end
        if par.wave_mode==3
            subplot(211);cla;pcolor(x,y,uz),caxis([-mag,mag]/2);axis equal;colorbar;axis on;shading interp;hold on;plot([par.transducer,par.transducer],[0,Ly],'k',[par.transducer+Lx,par.transducer+Lx],[0,Ly],'r','LineWidth',1.5);plot([0,0],[0,Ly],'k--',[0,Lx+2*par.transducer],[Ly,Ly],'k--',[0,Lx+2*par.transducer],[0,0],'k--',[Lx,Lx]+2*par.transducer,[0,Ly],'k--','LineWidth',1.5);hold off;title('z displacement \mum');
            subplot(212);cla;plot(dt*[1:length(rec_l_z)],(rec_l_z),'k',dt*[1:length(rec_l_z)],(rec_r_z),'r','LineWidth',1.5);axis on,box on;ylim([-mag/2,mag/2]*1.05);set(gca,'ytick',[]);xlabel('receiver signal (\mus)')
        end
        drawnow
    end
end
%==========================================================================
%determine velocity and output result
if par.wave_mode==1
    v     =   Lx / 1e3 / (time(rec_r_x==max(rec_r_x)) - time(rec_l_x==max(rec_l_x)));
    fid               =    fopen('result.txt','wt');
    fprintf(fid,'%s\n','t (micro s)  Left signal  Right signal  (ux)');
    for ii = 1:length(time)
        fprintf(fid,'%s\n',[num2str(time(ii)),'    ',num2str(rec_l_x(ii)),'    ',num2str(rec_r_x(ii))]);
    end
    fclose all;
end
if par.wave_mode==2
    v     =   Lx / 1e3 / (time(rec_r_y==max(rec_r_y)) - time(rec_l_y==max(rec_l_y)));
    fid               =    fopen('result.txt','wt');
    fprintf(fid,'%s\n','t (micro s)  Left signal  Right signal  (uy)');
    for ii = 1:length(time)
        fprintf(fid,'%s\n',[num2str(time(ii)),'    ',num2str(rec_l_y(ii)),'    ',num2str(rec_r_y(ii))]);
    end
    fclose all;
end
if par.wave_mode==3
    v     =   Lx / 1e3 / (time(rec_r_z==max(rec_r_z)) - time(rec_l_z==max(rec_l_z)));
    fid               =    fopen('result.txt','wt');
    fprintf(fid,'%s\n','t (micro s)  Left signal  Right signal  (uz)');
    for ii = 1:length(time)
        fprintf(fid,'%s\n',[num2str(time(ii)),'    ',num2str(rec_l_z(ii)),'    ',num2str(rec_r_z(ii))]);
    end
    fclose all;
end

%FINAL RESULT
disp(['Velocity = ',num2str(v),'km/s'])